'use client';
import { useState, useEffect } from 'react';
import ParameterKnob from '@/components/ParameterKnob';
import { rankingYears, categories } from '@/lib/config';

export default function ParametersPage() {
  const [tlr, setTlr] = useState(0);
  const [rpp, setRpp] = useState(0);
  const [go, setGo] = useState(0);
  const [oi, setOi] = useState(0);
  const [perc, setPerc] = useState(0);


  const [year, setYear] = useState('');
  const [category, setCategory] = useState('');
  const [institution, setInstitution] = useState('');
  const [institutions, setInstitutions] = useState([]);

  const parameters = [
    { label: 'Teaching & Learning Resources', value: tlr, setValue: setTlr, color: '#3B82F6' },
    { label: 'Research & Professional Practice', value: rpp, setValue: setRpp, color: '#10B981' },
    { label: 'Graduation Outcome', value: go, setValue: setGo, color: '#F59E0B' },
    { label: 'Outreach & Inclusivity', value: oi, setValue: setOi, color: '#8B5CF6' },
    { label: 'Perception', value: perc, setValue: setPerc, color: '#EF4444' },
  ];

  const handleSave = () => {
    const params = {
      tlr,
      rpp,
      go,
      oi,
      perc,
    };
    const selectedInstitution = institutions.find(inst => inst._id === institution);
    if (!selectedInstitution) {
      alert('Please select a valid institution');
      return;
    }
    params.year = year;
    params.category = category;
    params.institutionId = institution;
    fetch(`/api/updateParams`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    }).then((response) => {
      if (response.ok) {
        alert('Parameters saved successfully!');
      } else {
        alert('Error saving parameters. Please try again.');
      }
    }).catch((error) => {
      console.error('Error:', error);
      alert('Error saving parameters. Please try again.');
    });
    // Here you can send the parameters to your backend or perform any action you want
  }

  useEffect(() => {
    // Fetch institutions from an API or a static list
    const fetchInstitutions = async () => {
      // Replace with actual API call
      const response = await fetch(`/api/ranking?year=${year}&category=${category}`);
      const data = await response.json();
      if(data.data !== undefined){
        console.log(data.data);
        setInstitutions(data.data);
      } else {
        setInstitutions([]);
      }
    };

    fetchInstitutions();
  }, [year, category]);

  return (
    <div className="min-h-screen py-12 px-4 md:px-12 bg-white text-gray-800">
      <h1 className="text-4xl font-bold text-center mb-12">Evaluation Parameters</h1>

      <div className='flex gap-x-20 gap-y-4 md:flex-row flex-col mb-12'>
        <select
          className="p-2 border rounded md:w-1/3"
          value={year}
          onChange={(e) => setYear(e.target.value)}
        >
          <option value="">Select Year</option>
          {rankingYears.map((year) => (
            <option key={year} value={year}>
              {year}
            </option>
          ))}
        </select>

        <select
          className="p-2 border rounded md:w-1/3"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">Select Category</option>
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </option>
          ))}
        </select>

        <select
          className="p-2 border rounded md:w-1/3"
          value={institution}
          onChange={(e) => setInstitution(e.target.value)}
        >
          <option value="">Select Institution</option>
          {institutions.map((inst) => (
            <option key={inst._id} value={inst._id}>
              {inst.institution}
            </option>
          ))}
          {/** This should be replaced with actual institution data fetching logic **/}
        </select>
      </div>


      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 justify-items-center">
        {parameters.map((param, idx) => (
          <div key={idx} className="flex flex-col items-center">
            <h2 className="mb-4 text-xl font-semibold text-center">{param.label}</h2>
            <ParameterKnob
              themeColor={param.color}
              onChange={param.setValue}
            />
          </div>
        ))}
      </div>


      <div className="mt-12 text-center">
        <button className="cursor-pointer bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-200" onClick={handleSave}>
          Save Parameters
        </button>
      </div>
    </div>
  );
}
