import { NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Ranking from '@/models/Ranking'; // assuming your schema is named Institute

export async function POST(req) {
  try {
    await connectDB();

    const body = await req.json();
    const { tlr, rpp, go, oi, perc, year, category, institutionId } = body;

    if (!institutionId || !year || !category) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const totalScore = tlr + rpp + go + oi + perc;

    const updated = await Ranking.findOneAndUpdate(
      {
        _id: institutionId,
        year,
        category,
      },
      {
        $set: {
          score: totalScore,
        },
      },
    );

    if (!updated) {
      return NextResponse.json({ error: 'Institute not found' }, { status: 404 });
    }

    return NextResponse.json({ message: 'Parameters updated successfully', data: updated });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
