'use client';

import Link from 'next/link';
import { useKeenSlider } from 'keen-slider/react';
import 'keen-slider/keen-slider.min.css';
import { useEffect, useRef } from 'react';

export default function Home() {
  const [sliderRef, instanceRef] = useKeenSlider({
    loop: true,
    slides: { perView: 1 },
  });

  const timer = useRef();
  useEffect(() => {
    if (!instanceRef.current) return;
    timer.current = setInterval(() => {
      instanceRef.current.next();
    }, 3000);
    return () => clearInterval(timer.current);
  }, [instanceRef]);

  const images = [
    '/carousel/1.png',
    '/carousel/2.webp',
    '/carousel/3.jpg',
  ];

  return (
    <main>
      {/* Carousel */}
      <div ref={sliderRef} className="keen-slider w-full h-[300px] md:h-[500px] overflow-hidden">
        {images.map((src, idx) => (
          <div key={idx} className="keen-slider__slide">
            <img
              src={src}
              alt={`Slide ${idx + 1}`}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-20 text-center">
        <h1 className="text-5xl font-bold text-blue-700 mb-6">
          Discover the Most Accurate College Rankings in India
        </h1>
        <p className="text-gray-600 text-xl mb-10">
          Rankr helps students, parents, and educators make informed decisions using reliable, data-backed ranking systems.
        </p>

        {/* CTA Button */}
        <Link
          href="/ranking/"
          className="inline-block bg-blue-600 text-white font-semibold text-lg px-8 py-4 rounded-xl hover:bg-blue-700 transition"
        >
          View Latest Rankings
        </Link>

        {/* About Us Section */}
        <section className="mt-24 text-left bg-white py-16 px-6 sm:px-10 rounded-2xl shadow-md">
          <h2 className="text-3xl font-bold text-blue-700 mb-6 text-center">About Us</h2>
          <p className="text-gray-700 text-lg max-w-4xl mx-auto text-center leading-relaxed">
            Rankr is a student-led initiative focused on bringing clarity and credibility to college rankings in India.
            We believe in transparency, data-backed evaluation, and student empowerment. 
            Whether you're a student looking for the best fit, a parent guiding your child, or an educator striving for excellence,
            Rankr provides the tools and insights you need to make informed choices.
          </p>
        </section>

        {/* Features Section */}
        <section className="mt-28 grid gap-12 md:grid-cols-3 text-left">
          <div className="p-8 bg-gray-50 rounded-2xl shadow-md hover:shadow-lg transition">
            <h3 className="text-2xl font-semibold text-blue-600 mb-4">Data-Driven</h3>
            <p className="text-gray-700 text-lg">
              Built on parameters that actually matter—placements, research, faculty, and more.
            </p>
          </div>

          <div className="p-8 bg-gray-50 rounded-2xl shadow-md hover:shadow-lg transition">
            <h3 className="text-2xl font-semibold text-blue-600 mb-4">Transparent</h3>
            <p className="text-gray-700 text-lg">
              Know exactly why a college ranks where it does. No shady algorithms or hidden criteria.
            </p>
          </div>

          <div className="p-8 bg-gray-50 rounded-2xl shadow-md hover:shadow-lg transition">
            <h3 className="text-2xl font-semibold text-blue-600 mb-4">Up-to-Date</h3>
            <p className="text-gray-700 text-lg">
              Rankings updated yearly with the latest and most trusted data from institutions.
            </p>
          </div>
        </section>

        {/* Parameters Section */}
        <section className="mt-28 text-left">
          <h2 className="text-3xl font-bold text-blue-700 mb-6 text-center">We Evaluate Based on 5 Key Parameters</h2>
          <ul className="grid gap-6 md:grid-cols-2 text-gray-700 text-lg list-disc list-inside max-w-3xl mx-auto">
            <li><span className="font-medium">Teaching and Learning Resources</span></li>
            <li><span className="font-medium">Research and Professional Practice</span></li>
            <li><span className="font-medium">Graduation Outcome</span></li>
            <li><span className="font-medium">Outreach and Inclusivity</span></li>
            <li><span className="font-medium">Perception</span></li>
          </ul>
        </section>
      </div>
    </main>
  );
}
