import connectToDatabase from '@/lib/mongodb'; // Adjust path as necessary
import Ranking from '@/models/Ranking';

export async function GET(request) {
  const url = new URL(request.url);
  const year = url.searchParams.get('year'); // Get the year from the query parameter
  const category = url.searchParams.get('category'); // Get the category from the query parameter

  if (!year || !category) {
    return new Response(
      JSON.stringify({ success: false, message: 'Year and Category are required' }),
      { status: 400 }
    );
  }

  // Connect to MongoDB
  await connectToDatabase();

  try {
    // Fetch rankings for the given year and category
    const rankings = await Ranking.find({
      year: parseInt(year),
      category,
    }).sort({ rank: 1 }); // Sort by rank in ascending order

    if (rankings.length === 0) {
      return new Response(
        JSON.stringify({ success: false, message: 'No rankings found for this year and category' }),
        { status: 404 }
      );
    }

    return new Response(JSON.stringify({ success: true, data: rankings }), {
      status: 200,
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, message: error.message }),
      { status: 500 }
    );
  }
}

export async function POST(request) {
  const { year, category, institution, rank, score, state, report } = await request.json();
  console.log({
    year,
    category,
    institution,
    rank,
    score,
    state,
    report
  }); // Debugging line
  
  if (!year || !category || !institution || !rank || !score || !state || !report) {
    return new Response(
      JSON.stringify({ success: false, message: 'All fields are required' }),
      { status: 400 }
    );
  }

  // Connect to MongoDB
  await connectToDatabase();

  try {
    // Create a new ranking entry
    const newRanking = new Ranking({
      year,
      category,
      institution,
      rank,
      score,
      state,
      report
    });

    await newRanking.save();

    return new Response(JSON.stringify({ success: true, data: newRanking }), {
      status: 201,
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, message: error.message }),
      { status: 500 }
    );
  }
}
