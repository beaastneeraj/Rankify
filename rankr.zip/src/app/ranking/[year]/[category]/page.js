'use client';
import { useEffect, useState, use } from 'react';
import Link from 'next/link';

export default function RankingPage({ params }) {
  const { year, category } = use(params); // Get year and category from route parameters
  const [rankings, setRankings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch rankings for the specific year and category
    const fetchRankings = async () => {
      const res = await fetch(`/api/ranking?year=${year}&category=${category}`);
      const data = await res.json();

      if (data.success) {
        setRankings(data.data);
      } else {
        console.error('Error fetching rankings:', data.message);
        setError(data.message);
      }
      setLoading(false);
    };

    fetchRankings();
  }, [year, category]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">
        {category.charAt(0).toUpperCase() + category.slice(1)} Rankings for {year}
      </h1>
      {error && (
        <div className="col-span-1 md:col-span-3 p-4 border border-red-200 bg-red-50 rounded-lg shadow-lg">
          <p className="text-red-600">{error}</p>
        </div>
      )}
      {rankings.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto border border-gray-300 rounded-lg shadow-lg">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-700">Rank</th>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-700">Institution</th>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-700">Score</th>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-700">State</th>
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-700">Report</th>
              </tr>
            </thead>
            <tbody>
              {rankings.map((ranking) => (
                <tr key={ranking._id} className="border-t">
                  <td className="px-4 py-2 text-gray-800">{ranking.rank}</td>
                  <td className="px-4 py-2 text-gray-800">{ranking.institution}</td>
                  <td className="px-4 py-2 text-gray-800">{ranking.score}</td>
                  <td className="px-4 py-2 text-gray-800">{ranking.state}</td>
                  <td className="px-4 py-2">
                    <Link
                      href={ranking.report || '#'}
                      target="_blank"
                      className="text-blue-600 underline"
                    >
                      View Report
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

    </div>
  );
}
