'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X } from 'lucide-react';
import { rankingYears } from '@/lib/config';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const pathname = usePathname();

  const navItems = [
    { name: 'Home', href: '/' },
    // { name: 'About', href: '/about' },
    { name: 'Parameters', href: '/parameters' },
    { name: 'Login', href: '/login' },
  ];


  return (
    <header className="bg-white shadow-md z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col items-center">
        {/* Logo */}
        <img src="/logo.jpg" alt="Rankr Logo" className="h-28 w-26 mb-2" />

        {/* Title */}
        <span className="text-3xl font-bold text-blue-600 mb-3">Rankr</span>

        {/* Desktop Navbar */}
        <nav className="hidden md:flex space-x-6 items-center">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`hover:text-blue-600 transition-colors ${
                pathname === item.href ? 'text-blue-600 font-semibold' : 'text-gray-700'
              }`}
            >
              {item.name}
            </Link>
          ))}

          {/* Rankings Dropdown (desktop) */}
          <div
            className="relative"
            onMouseEnter={() => setDropdownOpen(true)}
            onMouseLeave={() => setDropdownOpen(false)}
          >
            <button className="text-gray-700 hover:text-blue-600 transition-colors">
              Rankings
            </button>
            {dropdownOpen && (
              <div className="absolute bg-white border rounded shadow-md z-50">
                {rankingYears.map((year) => (
                  <Link
                    key={year}
                    href={`/ranking/${year}`}
                    className="block px-4 py-2 hover:bg-blue-50 text-gray-700 whitespace-nowrap"
                  >
                    {year}
                  </Link>
                ))}
              </div>
            )}
          </div>
        </nav>

        {/* Mobile Hamburger Button */}
        <div className="md:hidden mt-2">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="text-gray-700 hover:text-blue-600"
            aria-label="Toggle Menu"
          >
            {menuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="mt-4 w-full flex flex-col items-center space-y-3 md:hidden">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`hover:text-blue-600 transition-colors ${
                  pathname === item.href ? 'text-blue-600 font-semibold' : 'text-gray-700'
                }`}
                onClick={() => setMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}

            {/* Rankings Dropdown (mobile) */}
            <div className="w-full text-center">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="text-gray-700 hover:text-blue-600 transition-colors"
              >
                Rankings {dropdownOpen ? '▲' : '▼'}
              </button>
              {dropdownOpen && (
                <div className="mt-2 bg-white border rounded shadow-md w-40 mx-auto">
                  {rankingYears.map((year) => (
                    <Link
                      key={year}
                      href={`/ranking/${year}`}
                      className="block px-4 py-2 hover:bg-blue-50 text-gray-700"
                      onClick={() => {
                        setDropdownOpen(false);
                        setMenuOpen(false);
                      }}
                    >
                      {year}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
