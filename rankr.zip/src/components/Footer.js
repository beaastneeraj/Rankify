const Footer = () => {
  return (
    <footer className="bg-gray-100 text-gray-700 border-t mt-10">
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
        <div className="text-center md:text-left">
          <p className="text-sm">&copy; {new Date().getFullYear()} Rankr. All rights reserved.</p>
        </div>

        <div className="flex gap-6 text-sm">
          <a href="/" className="hover:text-blue-600 transition">Home</a>
          <a href="/ranking" className="hover:text-blue-600 transition">Rankings</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
