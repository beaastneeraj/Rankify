import mongoose from 'mongoose';
import { categories } from '@/lib/config';

const RankingSchema = new mongoose.Schema({
  year: {
    type: Number,
    // required: true,
  },
  category: {
    type: String,
    // required: true,
    enum: categories,
  },
  institution: {
    type: String,
    // required: true,
  },
  rank: {
    type: Number,
    // required: true,
  },
  score: {
    type: Number,
    // required: true,
  },
  state: {
    type: String,
    // required: true,
  },
  report: {
    type: String,
    // required: true,
  },
});

export default mongoose.models.Ranking || mongoose.model('Ranking', RankingSchema);
